/**
 * يقرأ هذا الملف البيانات من CASE_DATA (js/data.js) ويملأ الصفحة بها،
 * ويضيف التفاعلات: النسخ، المشاركة، والـ Lightbox.
 * لا حاجة لتعديل هذا الملف عند تحديث المحتوى — عدّل data.js فقط.
 */
(function () {
  const d = CASE_DATA;

  // ---------- SEO dynamic bits ----------
  if (d.seo.canonicalUrl) {
    document.querySelector('link[rel="canonical"]').href = d.seo.canonicalUrl;
  }
  if (d.seo.shareImage) {
    document.querySelector('meta[property="og:image"]').content = d.seo.shareImage;
    document.querySelector('meta[name="twitter:image"]').content = d.seo.shareImage;
  }

  // ---------- Diagnosis ----------
  const measureGrid = document.getElementById("measureGrid");
  d.diagnosis.measurements.forEach((m) => {
    const box = document.createElement("div");
    box.className = "measure-box";
    box.innerHTML = `<span class="label">${m.label}</span><span class="value">${m.value}</span>`;
    measureGrid.appendChild(box);
  });
  document.getElementById("diagnosisNote").textContent = d.diagnosis.note;
  document.getElementById("diagnosisDisclaimer").textContent = d.diagnosis.disclaimer;

  // ---------- Current status ----------
  document.getElementById("currentStatusText").textContent = d.currentStatus.text;

  // ---------- Treatment plan ----------
  const stepsList = document.getElementById("treatmentSteps");
  d.treatmentPlan.steps.forEach((step, i) => {
    const li = document.createElement("li");
    li.innerHTML = `<span class="num">${i + 1}</span><span>${step}</span>`;
    stepsList.appendChild(li);
  });
  document.getElementById("treatmentNote").textContent = d.treatmentPlan.note;

  // ---------- Humanitarian ----------
  document.getElementById("humanitarianText").textContent = d.humanitarianSituation.text;

  // ---------- Medical reports ----------
  // يتم اكتشاف التقارير تلقائيًا من محتوى مجلد assets/reports/ (عبر manifest.json
  // الذي يُنشأ تلقائيًا عند النشر)، بالإضافة لأي تقارير مُضافة يدويًا في data.js
  const reportGrid = document.getElementById("reportGrid");

  function renderReports(reports) {
    if (reports.length === 0) {
      reportGrid.innerHTML = `<div class="empty-note">سيتم إضافة التقارير الطبية إلى هذا القسم فور توفرها.</div>`;
      return;
    }
    reportGrid.innerHTML = "";
    reports.forEach((r) => {
      const isPdf = (r.type || "").toUpperCase() === "PDF";
      const card = document.createElement("div");
      card.className = "card report-card";
      card.innerHTML = `
        <div class="report-info">
          <div class="report-icon">${r.type}</div>
          <div>
            <div class="report-name">${r.name}</div>
            <div class="report-type">${r.type}</div>
          </div>
        </div>
        <div class="report-actions">
          <a class="btn btn-outline btn-sm" href="${r.file}" target="${isPdf ? "_blank" : "_self"}" rel="noopener">عرض</a>
          <a class="btn btn-outline btn-sm" href="${r.file}" download>تحميل</a>
        </div>`;
      reportGrid.appendChild(card);
    });
  }

  // ---------- Gallery ----------
  const galleryGrid = document.getElementById("galleryGrid");

  function renderGallery(images) {
    if (images.length === 0) {
      galleryGrid.innerHTML = `<div class="empty-note">سيتم إضافة صور الحالة إلى هذا القسم فور توفرها.</div>`;
      return;
    }
    galleryGrid.innerHTML = "";
    images.forEach((img) => {
      const item = document.createElement("div");
      item.className = "gallery-item";
      item.tabIndex = 0;
      item.setAttribute("role", "button");
      item.setAttribute("aria-label", "فتح الصورة: " + (img.alt || ""));
      item.innerHTML = `<img src="${img.src}" alt="${img.alt || ""}" loading="lazy" />`;
      item.addEventListener("click", () => openLightbox(img.src, img.alt || ""));
      item.addEventListener("keypress", (e) => {
        if (e.key === "Enter") openLightbox(img.src, img.alt || "");
      });
      galleryGrid.appendChild(item);
    });
  }

  // يحاول قراءة manifest.json (يُنشأ تلقائيًا)، وإن تعذّر ذلك (مثلاً عند فتح
  // الملف مباشرة من الجهاز بدون خادم محلي) يعرض فقط ما هو مُضاف يدويًا في data.js
  async function loadManifest(url) {
    try {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) return [];
      return await res.json();
    } catch (e) {
      return [];
    }
  }

  (async function initMedia() {
    const [reportManifest, imageManifest] = await Promise.all([
      loadManifest("assets/reports/manifest.json"),
      loadManifest("assets/images/manifest.json"),
    ]);

    const autoReports = reportManifest.map((r) => ({
      name: r.name,
      type: r.type,
      file: "assets/reports/" + r.file,
    }));
    const autoImages = imageManifest.map((i) => ({
      src: "assets/images/" + i.file,
      alt: i.alt,
    }));

    renderReports([...autoReports, ...d.medicalReports]);
    renderGallery([...autoImages, ...d.gallery]);
  })();

  function openLightbox(src, alt) {
    document.getElementById("lightboxImg").src = src;
    document.getElementById("lightboxImg").alt = alt;
    document.getElementById("lightbox").classList.add("open");
  }
  function closeLightbox() {
    document.getElementById("lightbox").classList.remove("open");
    document.getElementById("lightboxImg").src = "";
  }
  document.getElementById("lightboxClose").addEventListener("click", closeLightbox);
  document.getElementById("lightbox").addEventListener("click", (e) => {
    if (e.target.id === "lightbox") closeLightbox();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeLightbox();
  });

  // ---------- Updates ----------
  const updatesList = document.getElementById("updatesList");
  d.updates.forEach((u) => {
    const card = document.createElement("div");
    card.className = "card update-card";
    card.innerHTML = `
      <div class="update-date">${u.date}</div>
      <div class="update-title">${u.title}</div>
      <p class="update-text">${u.text}</p>`;
    updatesList.appendChild(card);
  });

  // ---------- Timeline ----------
  const timelineList = document.getElementById("timelineList");
  if (d.timeline.length === 0) {
    timelineList.innerHTML = `<div class="empty-note">سيتم إضافة أحداث الخط الزمني فور توفرها.</div>`;
  } else {
    d.timeline.forEach((t) => {
      const item = document.createElement("div");
      item.className = "timeline-item";
      item.innerHTML = `
        <div class="timeline-date">${t.date}</div>
        <div class="timeline-title">${t.title}</div>
        <div class="timeline-desc">${t.description}</div>`;
      timelineList.appendChild(item);
    });
  }

  // ---------- Official appeal ----------
  document.getElementById("appealTitle").textContent = d.officialAppeal.title;
  document.getElementById("appealText").textContent = d.officialAppeal.text;
  const appealMeta = document.getElementById("appealMeta");
  appealMeta.innerHTML = `
    <div><strong>تاريخ تقديم الكتاب:</strong> ${d.officialAppeal.submittedLetter.date}</div>
    <div><strong>الجهة:</strong> ${d.officialAppeal.submittedLetter.to}</div>
    <div>${d.officialAppeal.submittedLetter.status}</div>
    <div>${d.officialAppeal.alEinFollowUp}</div>
  `;

  // ---------- Mediator ----------
  document.getElementById("mediatorName").textContent = d.mediator.name;
  document.getElementById("mediatorText").textContent = d.mediator.roleText;
  document.getElementById("mediatorVerify").textContent = d.mediator.verificationNote;

  // ---------- Donation ----------
  document.getElementById("cardHolder").textContent = d.donation.cardHolder;
  document.getElementById("cardNumber").textContent = d.donation.cardNumber;
  document.getElementById("accountNumber").textContent = d.donation.accountNumber;
  document.getElementById("donationNote").textContent = d.donation.note;

  document.querySelectorAll("[data-copy-target]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-copy-target");
      const text = document.getElementById(targetId).textContent.trim();
      copyToClipboard(text, "تم نسخ الرقم");
    });
  });

  // ---------- Contact ----------
  const waList = document.getElementById("whatsappList");
  d.contact.whatsappNumbers.forEach((n) => {
    const url = n.link + "?text=" + encodeURIComponent(d.contact.whatsappMessage);
    const a = document.createElement("a");
    a.className = "btn btn-whatsapp btn-block";
    a.href = url;
    a.target = "_blank";
    a.rel = "noopener";
    a.innerHTML = `<span class="channel-icon">WhatsApp</span> — ${n.display}`;
    waList.appendChild(a);
  });

  document.getElementById("telegramLink").href = d.contact.telegram.link;

  if (d.contact.facebook.link) {
    document.getElementById("facebookLink").href = d.contact.facebook.link;
    document.getElementById("facebookCard").style.display = "block";
  }

  // ---------- Share ----------
  document.getElementById("shareBtn").addEventListener("click", async () => {
    const shareData = {
      title: d.seo.title,
      text: "ساعد في إيصال حالة رقية لؤي كاظم إبراهيم",
      url: d.seo.canonicalUrl || window.location.href,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        /* تم إلغاء المشاركة من قبل المستخدم — لا حاجة لفعل شيء */
      }
    } else {
      copyToClipboard(shareData.url, "تم نسخ رابط الحالة");
    }
  });

  // ---------- Toast + clipboard helper ----------
  let toastTimer;
  function showToast(msg) {
    const toast = document.getElementById("toast");
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function copyToClipboard(text, successMessage) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(text)
        .then(() => showToast(successMessage))
        .catch(() => fallbackCopy(text, successMessage));
    } else {
      fallbackCopy(text, successMessage);
    }
  }

  function fallbackCopy(text, successMessage) {
    const el = document.createElement("textarea");
    el.value = text;
    el.style.position = "fixed";
    el.style.opacity = "0";
    document.body.appendChild(el);
    el.select();
    try {
      document.execCommand("copy");
      showToast(successMessage);
    } catch (e) {
      showToast("تعذّر النسخ، يرجى النسخ يدويًا");
    }
    document.body.removeChild(el);
  }
})();
