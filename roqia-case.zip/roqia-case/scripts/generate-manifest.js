/**
 * يفحص هذا السكربت محتوى مجلدي assets/images و assets/reports تلقائيًا،
 * وينشئ ملف manifest.json داخل كل مجلد يحتوي أسماء الملفات الموجودة فعليًا.
 * يعمل تلقائيًا مع كل نشر عبر GitHub Actions — لا حاجة لتشغيله يدويًا.
 */
const fs = require("fs");
const path = require("path");

function humanize(filename) {
  const base = filename.replace(/\.[^/.]+$/, "");
  return base.replace(/[-_]+/g, " ").trim();
}

function isSkipped(filename) {
  const lower = filename.toLowerCase();
  return (
    lower.startsWith(".") ||
    lower === "readme.md" ||
    lower === "manifest.json"
  );
}

function buildManifest(dirPath, kind) {
  if (!fs.existsSync(dirPath)) return;
  const files = fs
    .readdirSync(dirPath)
    .filter((f) => !isSkipped(f) && fs.statSync(path.join(dirPath, f)).isFile());
  files.sort();

  const items = files.map((f) => {
    const ext = path.extname(f).replace(".", "").toUpperCase();
    if (kind === "reports") {
      return { file: f, name: humanize(f), type: ext };
    }
    return { file: f, alt: humanize(f) };
  });

  fs.writeFileSync(
    path.join(dirPath, "manifest.json"),
    JSON.stringify(items, null, 2) + "\n"
  );
  console.log(`(${kind}) تم إنشاء manifest.json — عدد الملفات: ${items.length}`);
}

const root = path.join(__dirname, "..");
buildManifest(path.join(root, "assets", "images"), "images");
buildManifest(path.join(root, "assets", "reports"), "reports");
